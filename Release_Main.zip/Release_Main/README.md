To launch an app run the .html file in the directory or the game you want to launch. Usually named index.html
