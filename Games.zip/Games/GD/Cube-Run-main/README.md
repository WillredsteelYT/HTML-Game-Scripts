# Cube-Run
A simple cube game made in Javascript
